package dk.htmlwidget

import android.app.Presentation
import android.appwidget.AppWidgetManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.os.Handler
import android.os.Looper
import android.view.PixelCopy
import android.view.View
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.RemoteViews
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt

class WebsiteRefreshWorker(
    context: Context,
    params: WorkerParameters
) : Worker(context, params) {

    override fun doWork(): Result {
        val appWidgetId = inputData.getInt(
            KEY_WIDGET_ID,
            AppWidgetManager.INVALID_APPWIDGET_ID
        )

        if (appWidgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            return Result.failure()
        }

        val prefs = applicationContext.getSharedPreferences(
            "settings",
            Context.MODE_PRIVATE
        )

        val address = prefs.getString(
            "url_$appWidgetId",
            ""
        )?.trim().orEmpty()

        if (!address.startsWith("https://") &&
            !address.startsWith("http://")
        ) {
            return Result.failure()
        }

        val done = CountDownLatch(1)
        var success = false

        Handler(Looper.getMainLooper()).post {
            renderOffscreen(
                appWidgetId = appWidgetId,
                address = address,
                adBlock = prefs.getBoolean("adblock", true)
            ) {
                success = it
                done.countDown()
            }
        }

        // Giv dynamiske sider tid til at indlæse og blive tegnet.
        if (!done.await(25, TimeUnit.SECONDS)) {
            return Result.retry()
        }

        return Result.success()
    }

    private fun renderOffscreen(
        appWidgetId: Int,
        address: String,
        adBlock: Boolean,
        finished: (Boolean) -> Unit
    ) {
        val context = applicationContext
        val manager = AppWidgetManager.getInstance(context)
        val options = manager.getAppWidgetOptions(appWidgetId)
        val density = context.resources.displayMetrics.density

        val width = (
            options.getInt(
                AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH,
                300
            ) * density
        ).roundToInt().coerceAtLeast(1)

        val height = (
            options.getInt(
                AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT,
                180
            ) * density
        ).roundToInt().coerceAtLeast(1)

        val displayManager = context.getSystemService(
            Context.DISPLAY_SERVICE
        ) as DisplayManager

        val imageReader = ImageReader.newInstance(
            width,
            height,
            PixelFormat.RGBA_8888,
            2
        )

        var virtualDisplay: VirtualDisplay? = null
        var presentation: Presentation? = null
        var web: WebView? = null
        var completed = false

        fun cleanup(ok: Boolean) {
            if (completed) return
            completed = true

            try {
                web?.stopLoading()
                web?.destroy()
            } catch (_: Exception) {
            }

            try {
                presentation?.dismiss()
            } catch (_: Exception) {
            }

            try {
                virtualDisplay?.release()
            } catch (_: Exception) {
            }

            try {
                imageReader.close()
            } catch (_: Exception) {
            }

            finished(ok)
        }

        try {
            virtualDisplay = displayManager.createVirtualDisplay(
                "HtmlWidget-$appWidgetId",
                width,
                height,
                context.resources.displayMetrics.densityDpi,
                imageReader.surface,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY
            )

            val display = virtualDisplay?.display
                ?: run {
                    cleanup(false)
                    return
                }

            presentation = Presentation(context, display)

            web = WebView(context).apply {
                setLayerType(View.LAYER_TYPE_SOFTWARE, null)

                settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    loadsImagesAutomatically = true
                    useWideViewPort = true
                    loadWithOverviewMode = false
                    offscreenPreRaster = true
                }
            }

            presentation?.setContentView(web)
            presentation?.show()

            val currentWeb = web ?: run {
                cleanup(false)
                return
            }

            currentWeb.webViewClient = object : WebViewClient() {

                override fun shouldInterceptRequest(
                    view: WebView?,
                    request: WebResourceRequest?
                ): WebResourceResponse? {
                    if (!adBlock) {
                        return super.shouldInterceptRequest(view, request)
                    }

                    val host = request?.url?.host?.lowercase()
                        ?: return super.shouldInterceptRequest(view, request)

                    val blocked = listOf(
                        "doubleclick.net",
                        "googlesyndication.com",
                        "googleadservices.com",
                        "adservice.google.com",
                        "adnxs.com",
                        "criteo.com",
                        "criteo.net",
                        "scorecardresearch.com",
                        "taboola.com",
                        "outbrain.com"
                    )

                    if (blocked.any { host == it || host.endsWith(".$it") }) {
                        return WebResourceResponse(
                            "text/plain",
                            "UTF-8",
                            null
                        )
                    }

                    return super.shouldInterceptRequest(view, request)
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    if (completed) return

                    currentWeb.postDelayed({
                        if (completed) return@postDelayed

                        currentWeb.postVisualStateCallback(
                            1L,
                            object : WebView.VisualStateCallback() {
                                override fun onComplete(requestId: Long) {
                                    if (completed) return

                                    currentWeb.postDelayed({
                                        if (completed) return@postDelayed

                                        val bitmap = Bitmap.createBitmap(
                                            width,
                                            height,
                                            Bitmap.Config.ARGB_8888
                                        )

                                        val window = presentation?.window
                                        if (window == null) {
                                            cleanup(false)
                                            return@postDelayed
                                        }

                                        PixelCopy.request(
                                            window,
                                            bitmap,
                                            { result ->
                                                if (result == PixelCopy.SUCCESS) {
                                                    val views = RemoteViews(
                                                        context.packageName,
                                                        R.layout.widget_layout
                                                    )
                                                    views.setImageViewBitmap(
                                                        R.id.widget_image,
                                                        bitmap
                                                    )
                                                    manager.updateAppWidget(
                                                        appWidgetId,
                                                        views
                                                    )
                                                    cleanup(true)
                                                } else {
                                                    cleanup(false)
                                                }
                                            },
                                            Handler(Looper.getMainLooper())
                                        )
                                    }, 700)
                                }
                            }
                        )
                    }, 4000)
                }
            }

            currentWeb.loadUrl(address)

            // Sikkerhedsnet, så en fastlåst WebView ikke bliver hængende.
            Handler(Looper.getMainLooper()).postDelayed({
                if (!completed) cleanup(false)
            }, 22000)

        } catch (_: Exception) {
            cleanup(false)
        }
    }

    companion object {
        private const val KEY_WIDGET_ID = "appWidgetId"

        fun enqueue(context: Context, appWidgetId: Int) {
            val request = OneTimeWorkRequestBuilder<WebsiteRefreshWorker>()
                .setInputData(
                    workDataOf(KEY_WIDGET_ID to appWidgetId)
                )
                .build()

            WorkManager.getInstance(context).enqueueUniqueWork(
                "website-widget-refresh-$appWidgetId",
                ExistingWorkPolicy.REPLACE,
                request
            )
        }
    }
}
